# Pricing Optimization at Bosch Corporation

## Project Overview

This project aims to optimize Bosch's product price using machine learning techniques, specifically "XGBoost". The model uses key features such as "Demand Elasticity", "Competitor Pricing", and "Customer Preferences" to discover the optimal pricing points for maximizing sales and market competitiveness.

## Project Structure

The following is the structure of the project:

FinalProject_Price_Optimization/
├── pricing_optimization/             # Project directory
│   ├── app.py                        # Flask application code
│   ├── xgboost_model.joblib          # Saved XGBoost model
│   ├── requirements.txt              # List of dependencies (Flask, XGBoost, etc.)
│   └── README.md                     # Project documentation
└── Other necessary files...          # Jupyter notebook, pricing_data.csv, optimal-key.pem


## Installation Instructions

### 1. Clone the Repository
First, clone this repository to your local machine using the following command:
```bash
git clone https://github.com/mkazu1234/PricingOptimization-Bosch.git

### 2. Install Required Dependencies
pip install -r requirements.txt

### 3. Prepare the Dataset
Ensure the dataset pricing_data.csv is placed in the FinalProject_Price_Optimization/ directory

## Model Training

### 1. Training the XGBoost Model
'''bash
 c:\Users\Admin\FinalProject_Price_Optimization>jupyter notebook

it will run the FP_PricingOptimization.ipynb script and the trained model saved as "xgboost_model.joblib".

## Model Deployment

### 1. Set Up EC2 Instance
Launch an EC2 instance using SSH into the instance and install the necessary packages
'''bash
sudo yum install python3 -y
sudo yum install python3-pip -y
pip3 install flask numpy joblib xgboost

### 2. Upload Project Files
'''bash
scp -i "C:/Users/Admin/FinalProject_Price_Optimization/optimal-key.pem" xgboost_model.joblib ec2-user@51.21.2.221:/home/ec2-user/pricing_optimization


### 3. Create and Add the Flask App on the EC2 Instance

### 3. Running the Flask App
Navigate to the project directory on the EC2 instance and start the Flask API.
'''bash
python3 app.py

## Deployed Link

Using cURL command prompt – 

Prediction Test 1:
C:\Users\Admin\FinalProject_Price_Optimization>curl -X POST http://51.21.2.221:5000/predict -H "Content-Type: application/json" -d "{\"input\": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0]}"

Output - {"prediction":[255.20626831054688]}

Prediction Value: The predicted output from your model is approximately 255.21. This value represents the model's estimate based on the input features provided in your request

Prediction Test 2:
C:\Users\Admin\FinalProject_Price_Optimization>curl -X POST http://51.21.2.221:5000/predict -H "Content-Type: application/json" -d "{\"input\": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0]}"

Output - {"prediction":[283.8839416503906]}

Prediction Value: Based on the provided input features, the model predicts a value of approximately 283.88. Similar to the previous prediction, this value should be evaluated in the context of your application.

Using Web browser -  http://51.21.2.221:5000/predict


### Results

Model Performance:
XGBoost MSE: 150.4129
This is the average squared difference between predicted optimal prices and actual prices. A lower MSE suggests better prediction accuracy, and 150.4129 shows the model performs well but still has room for improvement.

XGBoost R² Score: 0.9722
This means the model explains 97.22% of the variance in pricing data, indicating that it is highly effective at capturing the relationships between features and target values.

Average Price Elasticity: -0.0489
This shows that demand is relatively inelastic; a 1% increase in price leads to only a 0.0489% decrease in demand, suggesting that small price changes have a minor impact on demand.

The results indicate that the model effectively predicts optimal prices based on various factors, helping Bosch to enhance its pricing strategies.






